<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    <script>
        lucide.createIcons();
      </script>
      <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
      <script src="assets/js/main.js"></script>
</body>
</html>