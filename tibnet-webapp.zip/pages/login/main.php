<form class="login" method="POST">
        <div class="login-box">
            <h1>TibNet</h1>
            <div class="input phone">
                <div class="icon">
                    <i data-lucide="phone"></i>
                </div>
                <div class="input-data">
                    <input type="text" placeholder="998YYYXXZZ" class="phone" id="phone" inputmode="numeric" maxlength="12">
                </div>
</div>
                <div id="pass" style="display: none;">
                <div class="input">
                
                <div class="input-data">
                    <input type="password" id="password" placeholder="Parol" autocomplete="off" class="phone" maxlength="12">
                </div>
                <div class="icon" id="show">
                    <i data-lucide="eye"></i>
                </div>
                </div>
                </div>
                <div id="reg" style="display: none;">
                
            <div class="input">
                <div class="icon">
                    <i data-lucide="user"></i>
                </div>
                <div class="input-data">
                    <input type="text" placeholder="FIO" autocomplete="off" class="phone" maxlength="12">
                </div>
                
            </div>

            
                </div>
                <button style="display: none;" id="sign_in" name="sign" value="in" class="btn">Kirish</button>
                <button style="display: none;" id="sign_up" name="sign" value="up" class="btn">Ro'yxatdan o'tish</button>
            </div>
           
    </form>